package com.hotel.billing.invoice.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.billing.invoice.dao.InvoiceDAO;
import com.hotel.billing.invoice.entity.Invoice;
import com.hotel.billing.order.dao.OrderDAO;
import com.hotel.billing.order.entity.Order;

@Service
@Transactional
public class InvoiceService {

    @Autowired
    private InvoiceDAO invoiceDAO;

    @Autowired
    private OrderDAO orderDAO;

    public Invoice generateInvoice(Long orderId) {

        Order order = orderDAO.getOrder(orderId);

        if (order == null) {
            throw new RuntimeException("Order not found");
        }

        double subTotal = order.getTotalPrice();
        double gst = subTotal * 0.18;
        double total = subTotal + gst;

        Invoice invoice = new Invoice();
        invoice.setOrderId(orderId);
        invoice.setCustomerName(order.getCustomerName());
        invoice.setSubTotal(subTotal);
        invoice.setGst(gst);
        invoice.setTotalAmount(total);
        invoice.setDate(LocalDate.now());

        invoiceDAO.saveInvoice(invoice);

        return invoice;
    }

    public Invoice getInvoice(Long id) {
        return invoiceDAO.getInvoice(id);
    }

    public List<Invoice> getAllInvoices() {
        return invoiceDAO.getAllInvoices();
    }

    public void deleteInvoice(Long id) {
        invoiceDAO.deleteInvoice(id);
    }
}