package com.hotel.billing.item.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hotel.billing.item.dao.ItemDAO;
import com.hotel.billing.item.entity.Item;

@Service
@Transactional
public class ItemService {

    @Autowired
    private ItemDAO itemDAO;

    public void addItem(Item item) {
        itemDAO.saveItem(item);
    }

    public List<Item> getItems() {
        return itemDAO.getAllItems();
    }

    public Item getItem(Long id) {
        return itemDAO.getItem(id);
    }

    public void deleteItem(Long id) {
        itemDAO.deleteItem(id);
    }

    public Item getItemByName(String name) {
        return itemDAO.getItemByName(name);
    }
    
    public Item getItemById(Long id) {
        return itemDAO.getItem(id);
    }
    
    @Transactional
    public void updateItem(Long id, Item newItem) {
        Item item = itemDAO.getItem(id);
        if (item != null) {
            item.setName(newItem.getName());
            item.setPrice(newItem.getPrice());
            itemDAO.saveItem(item);
        }
    }
}