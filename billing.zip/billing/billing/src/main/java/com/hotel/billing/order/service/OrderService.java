package com.hotel.billing.order.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.billing.invoice.dao.InvoiceDAO;
import com.hotel.billing.invoice.entity.Invoice;
import com.hotel.billing.item.dao.ItemDAO;
import com.hotel.billing.item.entity.Item;
import com.hotel.billing.order.dao.OrderDAO;
import com.hotel.billing.order.entity.Order;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderDAO orderDAO;

    @Autowired
    private ItemDAO itemDAO;

    @Autowired
    private InvoiceDAO invoiceDAO;

    public void saveOrder(Order order) {

        Item item = itemDAO.getItem(order.getItemId());

        if (item == null) {
            throw new RuntimeException("Item not found");
        }

        double subTotal = item.getPrice() * order.getQuantity();

        order.setItemName(item.getName());
        order.setTotalPrice(subTotal);

        // 🔥 STEP 1: SAVE ORDER
        Long orderId = orderDAO.saveOrder(order);

        // 🔥 STEP 2: CREATE INVOICE AUTOMATICALLY
        Invoice invoice = new Invoice();
        invoice.setOrderId(orderId);
        invoice.setCustomerName(order.getCustomerName());
        invoice.setSubTotal(subTotal);
        invoice.setGst(subTotal * 0.18);
        invoice.setTotalAmount(subTotal + (subTotal * 0.18));
        invoice.setDate(LocalDate.now());

        invoiceDAO.saveInvoice(invoice);
    }

    public Order getOrder(Long id) {
        return orderDAO.getOrder(id);
    }

    public List<Order> getAllOrders() {
        return orderDAO.getAllOrders();
    }

    public void deleteOrder(Long id) {
        orderDAO.deleteOrder(id);
    }

    public void updateOrder(Long id, Order newOrder) {

        Order existing = orderDAO.getOrder(id);

        if (existing == null) {
            throw new RuntimeException("Order not found");
        }

        Item item = itemDAO.getItem(newOrder.getItemId());

        if (item == null) {
            throw new RuntimeException("Item not found");
        }

        double total = item.getPrice() * newOrder.getQuantity();

        existing.setItemName(item.getName());
        existing.setQuantity(newOrder.getQuantity());
        existing.setTotalPrice(total);

        orderDAO.updateOrder(existing);
    }
}