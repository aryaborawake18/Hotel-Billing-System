package com.hotel.billing.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.billing.report.dto.ReportDTO;
import com.hotel.billing.report.service.ReportService;

@Service
public class DashboardService {

    @Autowired
    private ReportService reportService;

    public ReportDTO getDashboardData() {
        return reportService.getReport();
    }
}