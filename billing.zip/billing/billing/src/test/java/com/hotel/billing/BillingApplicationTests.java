package com.hotel.billing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingApplicationTests {

	@Test
	void contextLoads() {
	}

}
