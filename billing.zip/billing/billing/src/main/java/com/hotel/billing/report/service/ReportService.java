package com.hotel.billing.report.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.billing.invoice.dao.InvoiceDAO;
import com.hotel.billing.invoice.entity.Invoice;
import com.hotel.billing.report.dto.ReportDTO;

@Service
public class ReportService {

    @Autowired
    private InvoiceDAO invoiceDAO;

    // 🔥 COMMON CALC METHOD
    private ReportDTO buildReport(double income, double gst) {

        double revenue = income + gst;
        double cost = income * 0.60;   // demo cost logic
        double profit = revenue - cost;

        ReportDTO dto = new ReportDTO();
        dto.setTotalIncome(income);
        dto.setTotalGST(gst);
        dto.setTotalRevenue(revenue);
        dto.setTotalProfit(profit);

        return dto;
    }

    // ===================== ALL REPORT =====================
    public ReportDTO getReport() {

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {
            income += inv.getSubTotal();
            gst += inv.getGst();
        }

        return buildReport(income, gst);
    }

    // ===================== DATE REPORT =====================
    public ReportDTO getReportByDate(String dateStr) {

        LocalDate date = LocalDate.parse(dateStr);

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {
            if (inv.getDate().equals(date)) {
                income += inv.getSubTotal();
                gst += inv.getGst();
            }
        }

        return buildReport(income, gst);
    }

    // ===================== MONTH REPORT =====================
    public ReportDTO getReportByMonth(String month) {

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {

            String invMonth = inv.getDate().toString().substring(0, 7);

            if (invMonth.equals(month)) {
                income += inv.getSubTotal();
                gst += inv.getGst();
            }
        }

        return buildReport(income, gst);
    }

    // ===================== DAILY PROFIT =====================
    public ReportDTO getDailyProfit(String dateStr) {

        LocalDate date = LocalDate.parse(dateStr);

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {
            if (inv.getDate().equals(date)) {
                income += inv.getSubTotal();
                gst += inv.getGst();
            }
        }

        return buildReport(income, gst);
    }

    // ===================== MONTHLY PROFIT =====================
    public ReportDTO getMonthlyProfit(String month) {

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {

            String invMonth = inv.getDate().toString().substring(0, 7);

            if (invMonth.equals(month)) {
                income += inv.getSubTotal();
                gst += inv.getGst();
            }
        }

        return buildReport(income, gst);
    }

    // ===================== YEARLY PROFIT =====================
    public ReportDTO getYearlyProfit(String year) {

        List<Invoice> invoices = invoiceDAO.getAllInvoices();

        double income = 0;
        double gst = 0;

        for (Invoice inv : invoices) {

            if (inv.getDate() != null &&
                String.valueOf(inv.getDate().getYear()).equals(year)) {

                income += inv.getSubTotal();
                gst += inv.getGst();
            }
        }

        return buildReport(income, gst);
    }
}