package com.hotel.billing.dashboard.dto;

public class DashboardDTO {

    private long totalOrders;
    private double totalRevenue;
    private double totalProfit;
    private double totalGST;
    private double todaySales;
    private String topItem;
	public long getTotalOrders() {
		return totalOrders;
	}
	public void setTotalOrders(long totalOrders) {
		this.totalOrders = totalOrders;
	}
	public double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public double getTotalProfit() {
		return totalProfit;
	}
	public void setTotalProfit(double totalProfit) {
		this.totalProfit = totalProfit;
	}
	public double getTotalGST() {
		return totalGST;
	}
	public void setTotalGST(double totalGST) {
		this.totalGST = totalGST;
	}
	public double getTodaySales() {
		return todaySales;
	}
	public void setTodaySales(double todaySales) {
		this.todaySales = todaySales;
	}
	public String getTopItem() {
		return topItem;
	}
	public void setTopItem(String topItem) {
		this.topItem = topItem;
	}

    // getters & setters
}