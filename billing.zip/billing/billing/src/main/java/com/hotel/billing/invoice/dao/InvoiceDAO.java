package com.hotel.billing.invoice.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotel.billing.invoice.entity.Invoice;

@Repository
@Transactional
public class InvoiceDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public void saveInvoice(Invoice invoice) {
        sessionFactory.getCurrentSession().save(invoice);
    }

    public Invoice getInvoice(Long id) {
        return sessionFactory.getCurrentSession().get(Invoice.class, id);
    }

    public List<Invoice> getAllInvoices() {
        return sessionFactory.getCurrentSession()
                .createQuery("from Invoice", Invoice.class)
                .list();
    }

    public void deleteInvoice(Long id) {
        Invoice inv = getInvoice(id);
        if (inv != null) {
            sessionFactory.getCurrentSession().delete(inv);
        }
    }
}