package com.hotel.billing.report.dto;

import java.util.List;

public class ReportDTO {

    private double totalIncome;
    private double totalGST;
    private double totalRevenue;
    private double totalProfit;

    private List<ItemDTO> items;

    public double getTotalIncome() { return totalIncome; }
    public void setTotalIncome(double totalIncome) { this.totalIncome = totalIncome; }

    public double getTotalGST() { return totalGST; }
    public void setTotalGST(double totalGST) { this.totalGST = totalGST; }

    public double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(double totalRevenue) { this.totalRevenue = totalRevenue; }

    public double getTotalProfit() { return totalProfit; }
    public void setTotalProfit(double totalProfit) { this.totalProfit = totalProfit; }

    public List<ItemDTO> getItems() { return items; }
    public void setItems(List<ItemDTO> items) { this.items = items; }
}