let chart;

// ---------------- INIT ----------------
window.onload = function () {
    loadDashboard();
    loadItems();
    loadOrders();
    loadInvoices(); // 🔥 ADD किया (invoice auto load)
};

// ---------------- DASHBOARD ----------------
function loadDashboard() {

    fetch("http://localhost:8080/dashboard")
        .then(res => res.json())
        .then(d => {

            document.getElementById("income").innerText = d.totalIncome ?? 0;
            document.getElementById("gst").innerText = d.totalGST ?? 0;
            document.getElementById("revenue").innerText = d.totalRevenue ?? 0;
            document.getElementById("profit").innerText = d.totalProfit ?? 0;

            if (chart) chart.destroy();

            chart = new Chart(document.getElementById("chart"), {
                type: "pie",
                data: {
                    labels: ["Income", "GST", "Profit"],
                    datasets: [{
                        data: [
                            d.totalIncome ?? 0,
                            d.totalGST ?? 0,
                            d.totalProfit ?? 0
                        ]
                    }]
                }
            });
        })
        .catch(err => console.log("Dashboard error:", err));
}

// ---------------- ITEMS ----------------
function loadItems() {

    fetch("http://localhost:8080/items")
        .then(res => res.json())
        .then(data => {

            let items = Array.isArray(data) ? data : [];

            let html = "";

            items.forEach(i => {

                html += `
                <tr>
                    <td><button onclick="showItem(${i.id})">${i.id}</button></td>
                    <td>${i.name}</td>
                    <td>₹${i.price}</td>
                    <td><button onclick="placeOrder(${i.id})">Order</button></td>
                </tr>`;
            });

            document.getElementById("itemsTable").innerHTML = html;
        })
        .catch(err => console.log("Items error:", err));
}

// ---------------- ITEM DETAILS ----------------
function showItem(id) {

    fetch("http://localhost:8080/items/" + id)
        .then(res => res.json())
        .then(i => {

            document.getElementById("itemDetails").innerHTML =
                "📦 " + i.name + " | ₹" + i.price;
        })
        .catch(err => console.log("Item error:", err));
}

// ---------------- ORDER ----------------
function placeOrder(itemId) {

    let qty = prompt("Enter quantity:");

    if (!qty) return;

    fetch("http://localhost:8080/orders", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({
            itemId: itemId,
            quantity: Number(qty),
            customerName: "Walk-in"
        })
    })
    .then(res => res.text())
    .then(msg => {

        alert(msg);

        loadDashboard();
        loadItems();
        loadOrders();
        loadInvoices(); // 🔥 ADD किया (order के बाद invoice refresh)
    })
    .catch(err => console.log("Order error:", err));
}

// ---------------- ORDERS ----------------
function loadOrders() {

    fetch("http://localhost:8080/orders")
        .then(res => res.json())
        .then(data => {

            let orders = Array.isArray(data) ? data : [];

            let html = "<table><tr><th>ID</th><th>Item</th><th>Total</th></tr>";

            orders.forEach(o => {
                html += `
                <tr>
                    <td>${o.id}</td>
                    <td>${o.itemName}</td>
                    <td>₹${o.totalPrice}</td>
                </tr>`;
            });

            html += "</table>";

            document.getElementById("orders").innerHTML = html;
        })
        .catch(err => console.log("Orders error:", err));
}

// ---------------- INVOICE ----------------
function loadInvoices() {

    fetch("http://localhost:8080/invoices")
        .then(res => res.json())
        .then(data => {

            let invoices = Array.isArray(data) ? data : [];

            let html = "";

            invoices.forEach(inv => {

                html += `
                <tr>
                    <td>${inv.id}</td>
                    <td>${inv.orderId ?? '-'}</td>
                    <td>₹${inv.totalAmount ?? 0}</td>
                </tr>`;
            });

            document.getElementById("invoiceTable").innerHTML = html;
        })
        .catch(err => console.log("Invoice error:", err));
}

// ---------------- REPORT TYPE ----------------
function changeType(type) {

    document.getElementById("dateInput").style.display = "none";
    document.getElementById("monthInput").style.display = "none";
    document.getElementById("yearInput").style.display = "none";

    if (type === "daily") document.getElementById("dateInput").style.display = "inline";
    if (type === "monthly") document.getElementById("monthInput").style.display = "inline";
    if (type === "yearly") document.getElementById("yearInput").style.display = "inline";
}

// ---------------- REPORT ----------------
function loadReport() {

    let type = document.getElementById("reportType").value;

    let url = "";

    if (type === "daily") {

        let date = document.getElementById("dateInput").value;
        if (!date) return alert("Select date");

        url = "http://localhost:8080/reports/profit/daily?date=" + date;
    }

    if (type === "monthly") {

        let month = document.getElementById("monthInput").value;
        if (!month) return alert("Select month");

        url = "http://localhost:8080/reports/profit/month?month=" + month;
    }

    if (type === "yearly") {

        let year = document.getElementById("yearInput").value;
        if (!year) return alert("Enter year");

        url = "http://localhost:8080/reports/profit/year?year=" + year;
    }

    fetch(url)
        .then(res => {
            if (!res.ok) throw new Error("API error");
            return res.json();
        })
        .then(d => {

            document.getElementById("r_income").innerText = d.totalIncome ?? 0;
            document.getElementById("r_gst").innerText = d.totalGST ?? 0;
            document.getElementById("r_revenue").innerText = d.totalRevenue ?? 0;
            document.getElementById("r_profit").innerText = d.totalProfit ?? 0;
        })
        .catch(err => {
            console.log("Report error:", err);
            alert("Report API error");
        });
}