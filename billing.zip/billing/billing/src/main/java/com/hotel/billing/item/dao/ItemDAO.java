package com.hotel.billing.item.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotel.billing.item.entity.Item;

@Repository
public class ItemDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public void saveItem(Item item) {
        Session session = sessionFactory.getCurrentSession();
        session.save(item);
    }

    public List<Item> getAllItems() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from Item", Item.class).list();
    }

    public Item getItem(Long id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Item.class, id);
    }

    public void deleteItem(Long id) {
        Session session = sessionFactory.getCurrentSession();
        Item item = session.get(Item.class, id);
        if (item != null) {
            session.delete(item);
        }
    }

    public Item getItemByName(String name) {
        Session session = sessionFactory.getCurrentSession();

        Query<Item> query = session.createQuery(
            "from Item where name = :name", Item.class
        );
        query.setParameter("name", name);

        return query.uniqueResult();
    }
    
    public void updateItem(Long id, Item newItem) {
        Session session = sessionFactory.getCurrentSession();

        Item existingItem = session.get(Item.class, id);

        if (existingItem != null) {
            existingItem.setName(newItem.getName());
            existingItem.setPrice(newItem.getPrice());

            session.update(existingItem); // 🔥 update operation
        }
    }
}