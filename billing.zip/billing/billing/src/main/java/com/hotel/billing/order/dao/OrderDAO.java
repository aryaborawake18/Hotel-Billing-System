package com.hotel.billing.order.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotel.billing.order.entity.Order;

@Repository
public class OrderDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public Long saveOrder(Order order) {
        Session session = sessionFactory.openSession(); // 🔥 FIX
        session.beginTransaction();

        session.save(order);
        session.getTransaction().commit();
        session.close();

        return order.getId();
    }

    public Order getOrder(Long id) {
        Session session = sessionFactory.openSession();
        Order order = session.get(Order.class, id);
        session.close();
        return order;
    }

    public List<Order> getAllOrders() {
        Session session = sessionFactory.openSession();
        List<Order> list = session.createQuery("from Order", Order.class).list();
        session.close();
        return list;
    }

    public void deleteOrder(Long id) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Order order = session.get(Order.class, id);
        if (order != null) {
            session.delete(order);
        }

        session.getTransaction().commit();
        session.close();
    }

    public void updateOrder(Order order) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.update(order);

        session.getTransaction().commit();
        session.close();
    }
}