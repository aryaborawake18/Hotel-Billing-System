package com.hotel.billing.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.billing.report.dto.ReportDTO;
import com.hotel.billing.report.service.ReportService;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping
    public ReportDTO getReport() {
        return reportService.getReport();
    }

    @GetMapping("/date")
    public ReportDTO getByDate(@RequestParam String date) {
        return reportService.getReportByDate(date);
    }

    @GetMapping("/month")
    public ReportDTO getByMonth(@RequestParam String month) {
        return reportService.getReportByMonth(month);
    }

    @GetMapping("/year")
    public ReportDTO getByYear(@RequestParam String year) {
        return reportService.getYearlyProfit(year);
    }

    @GetMapping("/profit/daily")
    public ReportDTO dailyProfit(@RequestParam String date) {
        return reportService.getDailyProfit(date);
    }

    @GetMapping("/profit/month")
    public ReportDTO monthlyProfit(@RequestParam String month) {
        return reportService.getMonthlyProfit(month);
    }

    @GetMapping("/profit/year")
    public ReportDTO yearlyProfit(@RequestParam String year) {
        return reportService.getYearlyProfit(year);
    }
}